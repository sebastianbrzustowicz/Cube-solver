/*void choose(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9, int opcja);
void swap(int pierwsza, int druga);
void instrukcja();
void menu();
void plikreset();
void solve(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void scramble(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void softset(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void blueone(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);*/
void redone(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void greenone(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void orangeone(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void softcorners(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void edges(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void simpleoll(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void simplepll(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
//void completetest(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
//	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
//	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
//	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
//	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
//	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);

//class cube
//{
//    public:
//};







/*void F(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* w1, int* w2, int* w3,
	int* r7, int* r4, int* r1,
	int* y9, int* y8, int* y7,
	int* o3, int* o6, int* o9);
void Fp(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* w1, int* w2, int* w3,
	int* r7, int* r4, int* r1,
	int* y9, int* y8, int* y7,
	int* o3, int* o6, int* o9);
void FF(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* w1, int* w2, int* w3,
	int* r7, int* r4, int* r1,
	int* y9, int* y8, int* y7,
	int* o3, int* o6, int* o9);
void R(int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* w3, int* w6, int* w9,
	int* g7, int* g4, int* g1,
	int* y3, int* y6, int* y9,
	int* b3, int* b6, int* b9);
void Rp(int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* w3, int* w6, int* w9,
	int* g7, int* g4, int* g1,
	int* y3, int* y6, int* y9,
	int* b3, int* b6, int* b9);
void RR(int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* w3, int* w6, int* w9,
	int* g7, int* g4, int* g1,
	int* y3, int* y6, int* y9,
	int* b3, int* b6, int* b9);
void B(int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* w9, int* w8, int* w7,
	int* o7, int* o4, int* o1,
	int* y1, int* y2, int* y3,
	int* r3, int* r6, int* r9);
void Bp(int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* w9, int* w8, int* w7,
	int* o7, int* o4, int* o1,
	int* y1, int* y2, int* y3,
	int* r3, int* r6, int* r9);
void BB(int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* w9, int* w8, int* w7,
	int* o7, int* o4, int* o1,
	int* y1, int* y2, int* y3,
	int* r3, int* r6, int* r9);
void L(int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* w7, int* w4, int* w1,
	int* b7, int* b4, int* b1,
	int* y7, int* y4, int* y1,
	int* g3, int* g6, int* g9);
void Lp(int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* w7, int* w4, int* w1,
	int* b7, int* b4, int* b1,
	int* y7, int* y4, int* y1,
	int* g3, int* g6, int* g9);
void LL(int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* w7, int* w4, int* w1,
	int* b7, int* b4, int* b1,
	int* y7, int* y4, int* y1,
	int* g3, int* g6, int* g9);
void U(int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* b1, int* b2, int* b3,
	int* r1, int* r2, int* r3,
	int* g1, int* g2, int* g3,
	int* o1, int* o2, int* o3);
void Up(int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* b1, int* b2, int* b3,
	int* r1, int* r2, int* r3,
	int* g1, int* g2, int* g3,
	int* o1, int* o2, int* o3);
void UU(int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* b1, int* b2, int* b3,
	int* r1, int* r2, int* r3,
	int* g1, int* g2, int* g3,
	int* o1, int* o2, int* o3);
void D(int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9,
	int* g9, int* g8, int* g7,
	int* r9, int* r8, int* r7,
	int* b9, int* b8, int* b7,
	int* o9, int* o8, int* o7);
void Dp(int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9,
	int* g9, int* g8, int* g7,
	int* r9, int* r8, int* r7,
	int* b9, int* b8, int* b7,
	int* o9, int* o8, int* o7);
void DD(int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9,
	int* g9, int* g8, int* g7,
	int* r9, int* r8, int* r7,
	int* b9, int* b8, int* b7,
	int* o9, int* o8, int* o7);
void czytaj(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9,
	int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9,
	int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9,
	int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9,
	int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9,
	int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);
void customyellow(int* y1, int* y2, int* y3, int* y4, int* y5, int* y6, int* y7, int* y8, int* y9);
void customblue(int* b1, int* b2, int* b3, int* b4, int* b5, int* b6, int* b7, int* b8, int* b9);
void customred(int* r1, int* r2, int* r3, int* r4, int* r5, int* r6, int* r7, int* r8, int* r9);
void customgreen(int* g1, int* g2, int* g3, int* g4, int* g5, int* g6, int* g7, int* g8, int* g9);
void customorange(int* o1, int* o2, int* o3, int* o4, int* o5, int* o6, int* o7, int* o8, int* o9);
void customwhite(int* w1, int* w2, int* w3, int* w4, int* w5, int* w6, int* w7, int* w8, int* w9);*/
